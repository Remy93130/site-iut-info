function openDiv(toOpen, button){
	document.getElementById(toOpen).classList.add('open');
	button.onclick = function() { closeDiv(toOpen, button); }
	if(toOpen === "TRACK"){
		var el = new SimpleBar(document.getElementById('myElement'));
		el.getContentElement();
	}
}

function changeVisibility(select, group){
	if (select.selectedIndex == 1){
		document.getElementById(group).style.display = "block";
	} else {
		document.getElementById(group).style.display = "none";
	}
}

function openTrack(button, idTrack){
	document.getElementById(idTrack).classList.add('open');
	document.getElementById(idTrack).setAttribute("data-simplebar", "");
	button.onclick = function() { closeTrack(button, idTrack); }
}

function closeTrack(button, idTrack){
	document.getElementById(idTrack).classList.remove('open');
	document.getElementById(idTrack).removeAttribute("data-simplebar");
	button.onclick = function() { openTrack(button, idTrack); }
}

function closeDiv(toClose, button){
	document.getElementById(toClose).classList.remove('open');
	button.onclick = function() { openDiv(toClose, button); }
}

function useModal(idModal, idButton) {
	var modal = document.getElementById(idModal);
	var button = document.getElementById(idButton);
	modal.style.display = "block";

	button.onclick = function() {
		modal.style.display = "none";
	}

	window.onclick = function(event) {
		if (event.target == modal) {
			modal.style.display = "none";
		}
	} 
}

function displayFirstIframe() {
	var right = document.getElementById('MEDIA');
	if (right != null) {
		right.getElementsByTagName('iframe')[0].style.display = "block";
	}
}

function switchIframe(idInstru, idIframe) {
	var i;
	
	var instrusList = document.getElementById('SONGS').getElementsByClassName('song');
	var iframesList = document.getElementById('MEDIA').getElementsByTagName('iframe');
	
	// Switch display for good iframe
	for (i = 0; i < iframesList.length; i++) {
		if (iframesList[i].style.display == "block") {
			iframesList[i].style.display = "none";
		}
	}
	document.getElementById(idIframe).style.display = "block";
	
	// Switch active Instru's link
	for (i = 0; i < instrusList.length; i++) {
		if (instrusList[i].classList.contains('active')) {
			instrusList[i].classList.remove('active');
		}
	}
	document.getElementById(idInstru).classList.add('active');
}

function nextIframe() {
	var i, j, next;
	
	var iframesList = document.getElementById('MEDIA').getElementsByTagName('iframe');
	
	// Display next Iframe
	for (i = 0; i < iframesList.length; i++) {
		if (iframesList[i].style.display == "block") {
			j = i+1;
			next = ((i+1) % iframesList.length) + 1;  // Next Iframe's number
			iframesList[i].style.display = "none";
		}
	}
	document.getElementById("iframe-" + next.toString()).style.display = "block";
	
	// Switch next active Instru
	document.getElementById("instru-" + j.toString()).classList.remove('active');
	document.getElementById("instru-" + (next)).classList.add('active');
}

function previousIframe() {
	var i, j, previous;
	
	var iframesList = document.getElementById('MEDIA').getElementsByTagName('iframe');
	
	// Display previous Iframe
	for (i = 0; i < iframesList.length; i++) {
		if (iframesList[i].style.display == "block") {
			j = i+1;
			previous = i;
			if (previous == 0) {
				previous = iframesList.length;
			}
			iframesList[i].style.display = "none";
		}
	}
	document.getElementById("iframe-" + previous.toString()).style.display = "block";
	
	// Switch next active Instru
	document.getElementById("instru-" + j.toString()).classList.remove('active');
	document.getElementById("instru-" + (previous)).classList.add('active');
}

function instruSearch() {
    // Declare variables
    var input, filter, div, li, a, i;
    input = document.getElementById('INSTRUSEARCH');
    filter = input.value.toUpperCase();
    div = document.getElementById("SONGS");
    songs = div.getElementsByClassName('song');

    // Loop through all list items, and hide those who don't match the search query
    for (i = 0; i < songs.length; i++) {
        a = songs[i];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
            songs[i].style.display = "";
        } else {
            songs[i].style.display = "none";
        }
    }
}

function textSearch() {
	// Declare variables
    var filter, div, sep, texts, selection, i;
    filter = document.getElementById('TEXTSEARCH').value.toUpperCase();
    div = document.getElementById("TEXTS");
    texts = div.getElementsByClassName("text");
    sep = div.getElementsByClassName("separator");
    var selection = [0, 0, 0];


    if (document.getElementById('PRIVATE').classList.contains('selected'))
    	selection[0] = 1;
    if (document.getElementById('GROUP').classList.contains('selected'))
    	selection[1] = 1;
    if (document.getElementById('PUBLIC').classList.contains('selected'))
    	selection[2] = 1;

    // Loop through all list items, and hide those who don't match the search query
    var text;
    var eyes = div.getElementsByClassName("eye");
    var pointeye = 0;

    for (i = 0; i < texts.length; i++) {
    	text = texts[i];
    	if (text.classList.contains('group'))
    		break;
    	if ((text.innerHTML.toUpperCase().indexOf(filter) > -1)) {
			texts[i].style.display = "";
			sep[i].style.display = "";
			if (text.classList.contains("private")){
				eyes[pointeye].style.display =""; pointeye++; }
        } else {	            
        	texts[i].style.display = "none";
	        sep[i].style.display = "none";
	        if (text.classList.contains("private")){
				eyes[pointeye].style.display ="none"; pointeye++; }
		}
    }

    if (!(selection[0])) {
    	var eyes = div.getElementsByClassName("eye");
       	for (i = 0; i < texts.length; i++) {
	    	text = texts[i];
	    	if (text.classList.contains('group'))
	    		break;
	    	if (text.classList.contains('private')) {	            
	        	texts[i].style.display = "none";
		        sep[i].style.display = "none";
		    }
	    }
	    for (var i = eyes.length - 1; i >= 0; i--) {
	    	eyes[i].style.display = "none";
	    }
	}

	if (!(selection[2]))
       	for (i = 0; i < texts.length; i++) {
	    	text = texts[i];
	    	if (text.classList.contains('group'))
	    		break;
	    	if (text.classList.contains('public')) {          
	        	texts[i].style.display = "none";
		        sep[i].style.display = "none";
		    }
	    }
    
    var groups = div.getElementsByClassName("folder");

    if (!(selection[1])){
    	for (i = 0; i < groups.length; i++) {
    		groups[i].style.display = "none";
    	}
    	return;
    }


    for (i = 0; i < groups.length; i++) {
    	texts = groups[i].getElementsByClassName('text');
    	sep = groups[i].getElementsByClassName("separator");
    	groups[i].style.display = "";
    	for (var j = 0; j < texts.length; j++) {
			if (texts[j].innerHTML.toUpperCase().includes(filter)) {
				texts[j].style.display = "";
				sep[j].style.display = "";
				openGroup("group-"+(i+1).toString());
	        } else {
	            texts[j].style.display = "none";
	            sep[j].style.display = "none";
	        }
    	}
    	if (filter === "")
    		closeGroup("group-"+(i+1).toString());
    }

    var has;
    if (selection[1]){
    	for (i = 0; i < groups.length; i++) {
    		texts = groups[i].getElementsByClassName('text');
            has = 0;
	    	for (var j = 0; j < texts.length; j++) {
				if (!(texts[j].style.display === "none")) {
					has = 1;
					continue;
				}
	    	}
	    	if (has)
	    		groups[i].style.display = "";
	    	else
	    		groups[i].style.display = "none";
    	}
    }
}

function selectType(button){
	if (button.classList.contains('selected')){
		button.classList.remove('selected');
	}
	else{
		button.classList.add('selected');
	}
	textSearch();
}

function toggleGroup(idGroup){
	var group = document.getElementById(idGroup);
	if (group.classList.contains('open'))
		group.classList.remove('open');
	else
		group.classList.add('open');
}

function openGroup(idGroup){
	document.getElementById(idGroup).classList.add('open');
}

function closeGroup(idGroup){
	document.getElementById(idGroup).classList.remove('open');
}

function toggleNav(button){
	if (button.classList.contains('open')){
		button.classList.remove('open');
		document.getElementById("NAV").classList.remove('open');
	}
	else{
		button.classList.add('open');
		document.getElementById("NAV").classList.add('open');
	}
}